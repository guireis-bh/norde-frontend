<template>
  <section>
    Aqui
  </section>
</template>

<script>
export default {
  layout: 'default'
}
</script>
