import jquery from 'jquery'
import 'jquery-ui-bundle'

window.$ = window.jQuery = jquery
